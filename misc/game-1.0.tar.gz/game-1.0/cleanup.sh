#!/bin/sh
rm -rf **/*~ *~ config/ autom4te.cache/ m4/ aclocal.m4 configure *.in src/*.in
